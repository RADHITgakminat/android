package com.example.data_radhit2;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper dbHelper;
    EditText etName, etAge;
    TextView tvResult;
    Button btnAdd, btnView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        etName = findViewById(R.id.etName);
        etAge = findViewById(R.id.etAge);
        tvResult = findViewById(R.id.tvResult);
        btnAdd = findViewById(R.id.btnAdd);
        btnView = findViewById(R.id.btnView);

        // Button Tambah Data
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                int age = Integer.parseInt(etAge.getText().toString());

                boolean inserted = dbHelper.insertData(name, age);
                if (inserted) {
                    Toast.makeText(MainActivity.this, "Data Berhasil Ditambahkan", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Gagal Menambahkan Data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Button Lihat Data
        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor = dbHelper.getAllData();
                if (cursor.getCount() == 0) {
                    tvResult.setText("Tidak ada data");
                    return;
                }

                StringBuilder sb = new StringBuilder();
                while (cursor.moveToNext()) {
                    sb.append("ID: ").append(cursor.getInt(0)).append("\n");
                    sb.append("Nama: ").append(cursor.getString(1)).append("\n");
                    sb.append("Umur: ").append(cursor.getInt(2)).append("\n\n");
                }
                tvResult.setText(sb.toString());
            }
        });
    }
}
