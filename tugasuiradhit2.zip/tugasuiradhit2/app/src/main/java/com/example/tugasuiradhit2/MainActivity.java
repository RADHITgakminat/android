package com.example.tugasuiradhit2;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ProgressBar durationProgressBar;
    private Handler handler = new Handler();
    private int duration = 100; // Total durasi
    private int progress = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        durationProgressBar = findViewById(R.id.durationProgressBar);
        durationProgressBar.setMax(duration);

        // Simulasi durasi
        handler.postDelayed(updateProgress, 1000);
    }

    private Runnable updateProgress = new Runnable() {
        @Override
        public void run() {
            if (progress <= duration) {
                durationProgressBar.setProgress(progress);
                progress++;
                handler.postDelayed(this, 1000); // Perbarui setiap detik
            }
        }
    };
}